﻿using System;

namespace ProyectoRifle
{
    class Program
    {



        //SOBRECARGA DE FUNCIONES
        //2 o más funciones se pueden llamar igual, si hay un mecanismo para diferenciar
        //cuándo se llama a una o a otra
        //o bien porque se le pasa distinto número de parámetros
        //o bien porque los parámetros son de distinto tipo

        //PARÁMETROS POR DEFECTO
        //es el valor que se asigna si no se recibe otro



        static void Operar(int a = 1, int b = 3)
        {
            a = 7;
        }


        static void Operar(double x)
        {
            Operar();
            Operar(5);
            Operar(4, 3);

            x = 7*5;
        }


        static void Sumar(int[] array, ref int resultado) {
        
         


            for (int i = 0; i < array.Length; ++i) {
                resultado += array[i];
            }
            
        }



            static int Sumar(int a, int b=0,  int c=0 )
            {
                Console.WriteLine("Se ejecuta el 3");
                return a + b + c;
            }

        static int Resta(int a, int b = 0) {
            Sumar(2, 3);
            return a - b;
        }


        static void Main(string[] args)
        {
            

            Pistola pistola1 = new Pistola();
            pistola1.Disparar();
            pistola1.Recargar();

            

          
            Rifle rifle1 = new Rifle();
            Rifle rifle2 = new Rifle(5);

            rifle1.Disparar();

            Menu menu = new Menu();
            menu.Accion(rifle1);

            menu.Accion(rifle2);



        }
    }
}
