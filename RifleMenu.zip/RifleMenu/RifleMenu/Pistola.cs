﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoRifle
{
    class Pistola
    {
        public int NumBalas { get; private set; } = 0;

        public Pistola() { }

        public void Disparar() {
            if (NumBalas > 0)
            {
                Console.WriteLine("BANG!!");
                --NumBalas;
            }
            else {
                Console.WriteLine("No quedan balas!!");
            }
        }

        public void Recargar() {
            NumBalas = 5;
        }

    }
}
