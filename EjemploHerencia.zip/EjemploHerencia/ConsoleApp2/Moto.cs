﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class Moto:Vehiculo
    {
        public Moto(string color = "negro"): base(color) { }

        
        public override void Acelerar(int aceleracion)
        {
            //hago otra cosa
        }

        public override void Frenar()//override sobreescribe
        {
            if (velocidad > 0)
                velocidad--;

        }

    }
}
