﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    abstract class Transporte
    {
        //public, accesible desde cualquier clase
        //private, accesible solo desde la propia clase        
        //protected, se hereda y se puede utilizar en las clases hijas (y nietas)
        //pero para el resto de clases se comporta como si fuera privada
        int a;//si no especificas nada, es private
        protected int una_variable;
        private int otra_variable; 
        public void UnMetodo() { otra_variable = 7; }

        public Transporte() { }

    }
}
