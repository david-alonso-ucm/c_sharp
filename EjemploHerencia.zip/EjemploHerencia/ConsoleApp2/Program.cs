﻿using System;
using System.Net.Http.Headers;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
                    
            Coche[] coches = new Coche[10];//aquí todavía no tengo 10 coches, solo 10 huecos para meter coches
            for (int i = 0; i < coches.Length; ++i)
            {
                coches[i] = new Coche();
            }

            //ahora sí tengo 10 coches creados, y ya puedo "utilizarlos"
            coches[1].Acelerar();

            //un elemento de la clase padre puede contener objetos de la clase hija
            //pero no al reves
            Vehiculo[] lista_vehiculos = new Vehiculo[10];
            Random rnd = new Random();
            for (int i = 0; i < lista_vehiculos.Length; ++i) {
                if (rnd.Next(0, 2) == 0)
                    lista_vehiculos[i] = new Coche();
                else
                    lista_vehiculos[i] = new Moto();
            }

            //otra manera de hacer lo mismo, elemento por elemento
            lista_vehiculos[0] = new Coche("azul");
            lista_vehiculos[1] = new Moto("verde");
     

            Vehiculo un_vehiculo = new Moto();//si no le paso el color, se genera un moto de color negro
            Coche bmw = new Coche("rojo");
            lista_vehiculos[0] = un_vehiculo;
            lista_vehiculos[1] = bmw;


            for (int i = 0; i < lista_vehiculos.Length; i++)
                lista_vehiculos[i].Acelerar(10);
            
            
            Console.ReadKey();
        }
    }
}
