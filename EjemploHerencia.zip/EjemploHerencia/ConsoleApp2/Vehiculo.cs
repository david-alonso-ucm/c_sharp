﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
     abstract class Vehiculo:Transporte
    {
        //una clase abstracta es aquella que está concebida para que otras hereden de ella, 
        //pero no queremos crear objetos de esa clase


        private string color;
        protected int velocidad;
        public const int VELOCIDAD_MAXIMA = 200;


      
        public Vehiculo(string color)
        {
           
            this.color = color;
            velocidad = 0;
            //Console.WriteLine("Constructor Vehiculo "+ color);
        }

        public void Acelerar()
        {
            if (velocidad < Vehiculo.VELOCIDAD_MAXIMA)
                velocidad++;

            Console.WriteLine("Acelerando Vehiculo a " + velocidad);
        }

        public virtual void Acelerar(int aceleracion)
        {//le damos la opción a la clase de:
            // - no hacer nada, es decir, la función se hereda
            // - new, es decir, se oculta en la clase hija la función heredada
            // - override, es decir, se sobreescribe en la clase hija la función heredada

            if (velocidad + aceleracion < Vehiculo.VELOCIDAD_MAXIMA)
                velocidad += aceleracion;
            else
                velocidad = Vehiculo.VELOCIDAD_MAXIMA;

            Console.WriteLine("Acelerando Vehiculo a " + velocidad);
        }

        public abstract void Frenar();
        //métodos abstract solo pueden existir en clase abstract
        //un método abstracto no tiene cuerpo 
        //declarar un método abstracto obliga a las clases hijas a implementarlo

        public void Repostar() { 
            //llena gasolina 
        }


    }
}
