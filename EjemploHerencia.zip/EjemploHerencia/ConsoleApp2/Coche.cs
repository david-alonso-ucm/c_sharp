﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class Coche:Vehiculo
    {
        public new const int VELOCIDAD_MAXIMA = 250;
        private string marca;


        //si no se especifica la llamda al constructor de la clase padre
        //automáticamente se está llamando al constructor de la clase padre que no recibe parámetros (si existe)
        //es decir, que lo mismo no daría poner      public Coche(){}    que poner public Coche():base() {}

  

            //CONSTRUCTOR
            //se llama igual que la clase
            //no tiene valor de retorno porque el retorno siempre es el objeto construido
            //se ejecuta cuando creamos un objeto de esa clase
            //establece las condiciones iniciales en las que se crea un objeto (inicializar las propiedades, por ejemplo)

        public Coche():base("blanco")
        {
            una_variable = 7;
            //Console.WriteLine("Constructor Coche");
            marca  = Console.ReadLine();
        }

        public Coche(string color, string marca = "ACME"):base(color)
        { 
            //Console.WriteLine("Constructor Coche");
            this.marca = marca;
           
           
        }

        public new void Acelerar() {//ocultar la función de la clase padre
            //dicho de otra manera, se define un método genérico Acelerar() para todos los vehículos
            //pero yo quiero que el Coche acelere de una forma distinta
            //salvo que ese coche esté dentro de un contenedor de la clase padre, entonces se ejecuta el del padre
            int aceleracion = 7;
            if (velocidad + aceleracion < Coche.VELOCIDAD_MAXIMA)
                velocidad += aceleracion;
            else
                velocidad = Coche.VELOCIDAD_MAXIMA;

            Console.WriteLine("Acelerando coche a " + velocidad);
        }


        public override void Frenar()//override sobreescribe
        {//sobreescribir significa que en todo caso se va a ejecutar el método de la clase hija
            if (velocidad > 0)
                velocidad--;

        }

    }
}


/*PADRE         HIJA
 * nada          nada(heredar) / new
 * virtual       nada(heredar) / new / override
 * abstract      new (no lo haremos casi nunca) /  override
 * override      nada(heredar) / override
 */
