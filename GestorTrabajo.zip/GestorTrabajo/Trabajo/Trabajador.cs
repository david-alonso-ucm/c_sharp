﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trabajo
{
    class Trabajador
    {
        public string Nombre { get; private set; }
        
        
        private int _TiempoDisponible;
        public int TiempoDisponible { 
            get{ return _TiempoDisponible;  }
            private set { if (value < 0) _TiempoDisponible = 0;    else _TiempoDisponible = value;  }
        }

        private Tarea[] lista_tareas_asignadas = new Tarea[GestorTrabajo.TOTAL_TAREAS];//potencialmente un trabajador podría encargarse de todas las tareas si le diera tiempo
        private int contador_tareas_asignadas = 0;

        public Trabajador() {
            TiempoDisponible = 8 * 60; //el trabajador tiene una jornada labral de 8 horas, que convertimos a minutos
        }

        public bool AsignarTarea(Tarea tarea_asignada) {

            
            if (TiempoDisponible >= tarea_asignada.CosteTiempo) { 
                int i = contador_tareas_asignadas;//este paso no es necesario
                lista_tareas_asignadas[i] = tarea_asignada;
                lista_tareas_asignadas[i].CompletarTarea();
                TiempoDisponible -= lista_tareas_asignadas[i].CosteTiempo;
                ++contador_tareas_asignadas;
                return true;//asignación correcta
            }
            else
            {
                Console.WriteLine("El trabajador " + Nombre + " solo dispone de " + TiempoDisponible + " minutos, insuficiente para hacer la tarea que se trata de asignar, que necesita de " + tarea_asignada.CosteTiempo + " minutos");
                return false;//no se pudo asignar
            }
        }


    }
}
