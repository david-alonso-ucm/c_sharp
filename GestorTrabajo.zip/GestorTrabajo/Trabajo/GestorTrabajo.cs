﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Text;

namespace Trabajo
{
    class GestorTrabajo
    {
        public const int TOTAL_TAREAS = 10;
        Tarea[] lista_tareas; 
        Trabajador t1;

        public GestorTrabajo() {
            Random rnd = new Random();
            
            Console.WriteLine("\n\nGENERANDO TRABAJADOR...·");
            t1 = new Trabajador();
            Console.WriteLine("\n\nGENERANDO TAREAS...·");
            lista_tareas = new Tarea[TOTAL_TAREAS];
            for (int i = 0; i < TOTAL_TAREAS; ++i) {
                if (rnd.Next(0, 100) < 50) {//hay un 50% de probabilidad de que las tareas sean comerciales o administrativas
                    lista_tareas[i] = new TareaAdministrativa("prueba");
                }
                else{ 
                    lista_tareas[i] = new TareaComercial(20000);
                }
            }
            Console.WriteLine("\nPulse una tecla para continuar");
            Console.ReadKey();


            int opc; 

            do{
                opc = Menu(); //se almacenará un valor entre 1 y 3
                switch (opc) {
                    case 1:
                        MostrarTareas();
                        break;
                    
                    case 2:
                        if (AsignarTareas(t1))
                            Console.WriteLine("Tarea asignada con éxito");
                        else
                            Console.WriteLine("No se pudo asignar ninguna tarea");
                        break;
                    
                    case 3:
                        Console.WriteLine("Final del programa");
                        break;
                }
                Console.WriteLine("\nPulse una tecla para continuar");
                Console.ReadKey();

            }while (opc != 3); 
            
        }

        private int Menu() {
            int opc;
            Console.Clear();
            Console.WriteLine("1. Mostrar tareas");
            Console.WriteLine("2. Asignar tarea al trabajador");
            Console.WriteLine("3. Salir del programa");
            Console.Write("Escoja una opción: ");
            while (!int.TryParse(Console.ReadLine(), out opc) || opc < 1 || opc > 3) { 
                Console.Write("La opción introducida es incorrecta, inserta un valor que corresponda a las opciones disponibles: ");
            }

            return opc; 
        }

        private void MostrarTareas() {
            Console.Clear();
            Console.WriteLine("OPCIÓN 1 - MOSTRAR TAREAS\n");
            for (int i = 0; i < lista_tareas.Length; ++i) {
                Console.WriteLine("\nTarea " + i);
                lista_tareas[i].MostrarTarea();
            }
       
        }

        private bool AsignarTareas(Trabajador trabajador) {
            
            int opcion, contador_tareas = 0;

            if (trabajador.TiempoDisponible == 0) {
                Console.WriteLine("El trabajador "+ trabajador.Nombre+" no dispone de tiempo para la asignación de ninguna tarea más");
                return false; //al no poder hacerse la asignación, se sale de la función.
            }

            Console.WriteLine("OPCIÓN 2 - ASIGNAR TAREAS\n");
            Console.WriteLine("Listado de tareas sin realizar: ");
            for (int i = 0; i < lista_tareas.Length; ++i) {
                if (lista_tareas[i].Estado == "no realizada") {
                    Console.WriteLine("Tarea " + i + " - Tiempo necesario para realizarla: " + lista_tareas[i].CosteTiempo + " minutos");
                    ++contador_tareas;
                }
            
            }
            if (contador_tareas == 0) {
                Console.WriteLine("No quedan tareas pendientes de realizar");
                return false; //al no poder hacerse la asignación, se sale de la función.
            }

            //si llega aquí es porque quedan tareas por realizar y el trabajador dispone aún de algo de tiempo
            Console.WriteLine("\nTiempo del que dispone el trabajador " + trabajador.Nombre + ": " + trabajador.TiempoDisponible + " minutos");
            Console.WriteLine("Inserte el nº de la tarea que quiere asignar, o cualquier otra tecla para no asignar ninguna tarea");
            if(int.TryParse(Console.ReadLine(), out opcion) && opcion >= 0 && opcion < lista_tareas.Length && lista_tareas[opcion].Estado == "no realizada")
            {
                //si entra aquí es porque potencialmente la tarea se puede asignar
                return trabajador.AsignarTarea(lista_tareas[opcion]); //el´método AsignarTarea de la clase Trabajador devuelve true si la pudo asignar, y false si no fue posible por falta de tiempo disponible
            }
            else 
            {
                //Insertó una opción no válida, lo que significa que no se asigna la tarea
                return false;
            }



            
        }



    }
}
