﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trabajo
{
    abstract class Tarea
    {
        
        public abstract int MIN_TIEMPO { get; }
        public abstract int MAX_TIEMPO { get; }
        public string Tipo { get; private set; }
        public int CosteTiempo { get; protected set; } = 0;

        public string Estado { get; private set; } //true --> tarea realizada, false --> tarea por completar




        protected Tarea(string _Tipo) {
            this.Tipo = _Tipo;
            Console.WriteLine("Creando tarea "+Tipo);
            Estado = "no realizada";


        }

        public void GenerarTiempoTarea(int min, int max) {
            
            Random rnd = new Random();
            CosteTiempo = rnd.Next(min, max+1);
            //vamos a conseguir que sea múltiplo de 5
            CosteTiempo -= CosteTiempo%5; //redondeamos hacia abajo
           
        }
        
        public void CompletarTarea() {
            Estado = "realizada";
        }

        public virtual void MostrarTarea() {
            Console.WriteLine("\tTipo de tarea: "+Tipo);
            Console.WriteLine("\tDuración de la tarea: " + CosteTiempo+" minutos");
            Console.WriteLine("\tEstado de la tarea: " + Estado);
        }

    }
}
