﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trabajo
{
    class TareaComercial : Tarea
    {
        public const double PRESUPUESTO = 100000;//presupuesto para todas las tareas comerciales
        public static double Presupuesto_asignado = 0; //de entre todas las tareas comerciales con coste, 
        public override int MIN_TIEMPO { get { return 40; } }//el rango de valores de 40 a 120 minutos viene establecido en el enuciado del ejercicio
        public override int MAX_TIEMPO { get { return 120; } }


        private double _Coste;
        public double Coste
        {
            get { return _Coste; }
            private set
            {
                if (value < 0)
                {
                    Console.WriteLine("No es posible asignar un coste negativo. En su lugar se asignará 0");
                    _Coste = 0;
                }
                else if (value > (PRESUPUESTO - Presupuesto_asignado) )
                {
                    Console.WriteLine("No es posible asignar un coste de " + value + " por ser superior al presupuesto disponible, que es " + (PRESUPUESTO - Presupuesto_asignado) + ". Se asignará a la tarea el presupuesto disponible.");
                    _Coste = PRESUPUESTO - Presupuesto_asignado;//se le asigna lo que quede de presupuesto
                }
                else
                {
                    _Coste = value;
                }
            }
        }

        public TareaComercial(double _coste = -1) : base("Comercial")
        {
            
            if (_coste == -1)
            { //el -1 indica que no se ha asignado coste, y que por tanto hay que pedirlo por teclado
                Console.Write("Inserta el coste económico de la tarea comercial: ");
                while (!double.TryParse(Console.ReadLine(), out _coste))
                {
                    Console.Write("Error, el valor insertado no es numérico, inserta de nuevo: ");
                }
            }
            Coste = _coste;//asignación de valor, que ya sabemos en este punto que es numérico, a la propiedad Coste
            Presupuesto_asignado += Coste;
            GenerarTiempoTarea(MIN_TIEMPO, MAX_TIEMPO);
        }

        public override void MostrarTarea()
        {
            base.MostrarTarea();//se ejecuta la función de la clase padre
            Console.WriteLine("\tCoste económico de la tarea: " + Coste + " euros");

        }
    }
}
