﻿using System;

namespace Trabajo
{
    class Program
    {
        static void Main(string[] args)
        {
            GestorTrabajo g1 = new GestorTrabajo();

        }
    }
}
