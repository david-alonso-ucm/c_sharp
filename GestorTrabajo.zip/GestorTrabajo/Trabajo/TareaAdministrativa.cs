﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trabajo
{
    class TareaAdministrativa:Tarea
    {
        public override int MIN_TIEMPO { get { return 10; } }//el rango de valores de 10 a 80 minutos viene establecido en el enuciado del ejercicio
        public override int MAX_TIEMPO { get { return 80; } }
        public string Documentacion { get; private set; }
      
        
        public TareaAdministrativa(string _documentacion = ""):base("Administrativa"){
            if (_documentacion == "")
            {
                Console.Write("Inserta el texto con la descripción de la documentación asociada de la tarea administrativa: ");
                Documentacion = Console.ReadLine();
            }
            else {
                Documentacion = _documentacion;
            }
            
            GenerarTiempoTarea(MIN_TIEMPO, MAX_TIEMPO);

        }

        public override void MostrarTarea()
        {
            base.MostrarTarea();//se ejecuta la función de la clase padre
            Console.WriteLine("\tDocumentación asociada a la tarea '" + Documentacion + "'");

        }

    }
}
